﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutomationSoftwarePractice.Models
{
    public class SourceDestinationMachine
    {
        public int Id { get; set; }
        public string SourceMachineName { get; set; }

        public string DestinationMachineName { get; set; }

        public string Comments { get; set; }

        public List<SoftwareTransferDetails> SoftwareTransferDetails { get; set; }
    }
}
