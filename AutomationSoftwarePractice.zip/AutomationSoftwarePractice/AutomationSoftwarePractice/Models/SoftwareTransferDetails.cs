﻿namespace AutomationSoftwarePractice.Models
{
    public class SoftwareTransferDetails
    {
        public int Id { get; set; }
        public string SoftwareName { get; set; }
    }
}